Lamentablemente, por circunstancias extraordinarias, no hemos sido capaces de completar esta práctica satisfactoriamente y a tiempo.
Es por esto que hay múltiples ejercicios sin todas las pruebas necesarias o no finalizados.
Esperamos conseguir al menos una pequeña fracción de la nota y hacerlo mejor en las siguientes prácticas para conseguir aprobar por evaluación continua.

Muchas gracias por su ayuda y comprensión,
Un saludo,
Francisco Javier Arribas Gozalo